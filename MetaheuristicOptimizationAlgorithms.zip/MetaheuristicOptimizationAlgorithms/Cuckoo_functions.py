def cuckoo_search(n, pa, nd, bmin, bmax, fit_func, maxiter=100000, stdtol=1e-2):
    import numpy as np
    from copy import deepcopy

    def simple_bounds(s):

        s = np.array(s).reshape((1, 10))
        for i in range(10):
            if s[0, i] < bmin[i]:
                s[0, i] = bmin[i]
            elif s[0, i] > bmax[i]:
                s[0, i] = bmax[i]
        return s

    def get_cuckoos(nest, bestt):
        from scipy.special import gamma

        n1 = np.shape(nest)[0]
        m = np.shape(nest)[1]
        nest_old = deepcopy(nest)
        beta = 3 / 4
        sigma = ((gamma(1 + beta) * np.sin(np.pi * beta / 2)) / (
                gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (
                        1 / beta)
        for j in range(n1):
            s = nest_old[j]
            u = sigma * np.random.randn(1, m)
            v = np.random.randn(1, m)
            step = u / (np.abs(v) ** (1 / beta))
            # stepsize = (0.1 + np.random.rand() * 0.8) * step * (s - bestt)
            stepsize = 0.01 * step * (s - bestt)
            s = s + stepsize * np.random.randn(1, m)
            nest_old[j] = simple_bounds(s)

        return nest_old

    def get_best_nest(nest, newnest, best_value):
        nest_old = deepcopy(nest)
        n2 = np.shape(nest)[0]
        fnew = fit_func(newnest)
        for j in range(n2):
            if fnew[j] <= best_value[j]:
                best_value[j] = fnew[j]
                nest_old[j] = newnest[j]
        f_minn = np.amin(best_value)
        besta = nest_old[np.argmin(best_value)]
        return f_minn, besta, nest_old, best_value

    def empty_nests(nest):
        from copy import deepcopy

        n1 = np.shape(nest)[0]
        n2 = np.shape(nest)[1]
        k = np.random.rand(n1, n2) > pa

        nest_cop = deepcopy(nest)
        a = np.random.permutation(nest_cop)
        b = np.random.permutation(nest_cop)
        stepsize = np.random.rand(n1, n2) * (a - b)
        new_nest = nest + stepsize * k
        for j in range(n1):
            s = new_nest[j]
            new_nest[j] = simple_bounds(s)
        return new_nest

    list1 = []
    nests = bmin + (bmax - bmin) * np.random.rand(n, nd)
    fitness = 10 ** 5 * np.ones((n, 1))
    f_min, best_nest, nests, fitness = get_best_nest(nests, nests, fitness)
    for z in range(maxiter):
        new_nests = get_cuckoos(nests, best_nest)
        f_new, best, nests, fitness = get_best_nest(nests, new_nests, fitness)
        new_nests = empty_nests(nests)
        f_new, best, nests, fitness = get_best_nest(nests, new_nests, fitness)
        if f_new < f_min:
            f_min = f_new
            best_nest = best
        std = np.std(fitness)
        list1.append(np.amin(fitness))
        if std <= stdtol:
            break
        if z % 150 == 0:
            print('generation = {0} and best value = {1}'.format(z + 50, f_min))
    return list1, z
