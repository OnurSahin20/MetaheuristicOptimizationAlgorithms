def dea(p, f, cr, nd, bmin, bmax, fit_func, maxiter=5000, minprob=True, stdtol=1e-12):
    import numpy as np
    first_population = bmin + np.random.rand(p, nd) * (bmax - bmin)
    v = np.zeros((1, nd))
    jrand = np.random.randint(1, nd)

    list1 = []
    folds = fit_func(first_population)
    for z in range(maxiter):
        for j in range(p):

            r1 = np.random.randint(1, p)
            r2 = np.random.randint(1, p)
            r3 = np.random.randint(1, p)
            while r1 == r2 or r1 == r3 or r2 == r3:
                r1 = np.random.randint(1, p)
                r2 = np.random.randint(1, p)
                r3 = np.random.randint(1, p)
            irand = np.random.randint(1, nd + 1)
            for i in range(nd):
                if np.random.rand() < cr or jrand == irand:
                    v[0, i] = first_population[r1, i] + f * (first_population[r2][i] - first_population[r3][i])
                    if v[0, i] <= bmin[i] or v[0][i] >= bmax[i]:
                        v[0, i] = bmin[i] + np.random.rand() * (bmax[i] - bmax[i])
                else:
                    v[0, i] = first_population[j, i]
            fnew = fit_func(v)
            if minprob is True:
                if fnew <= folds[j]:
                    first_population[j] = v
                    folds[j] = fnew
            else:
                if fnew > folds[j]:
                    first_population[j] = v
                    folds[j] = fnew
        list1.append(np.min(folds))
        if z % 50 == 0:
            print('generation = {0} and best value = {1}'.format(z + 50, np.amin(folds)))

        std = np.std(folds)
        if std < stdtol:
            break
    return list1, z
