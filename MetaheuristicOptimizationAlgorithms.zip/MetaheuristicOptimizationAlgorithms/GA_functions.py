def genetic_algorithm(p, ndv, bmin, bmax, fit_func, generation=2000, pc=0.85, pm=0.03, minprob=True):
    import numpy as np

    m = 15
    first_pop = np.random.randint(0, 2, (p, ndv * m))

    def decoding(population):
        """this function does encoding and calculates decimal values of the decision variables
        p = population size : int
        ngi= number of genes in individuals : int
        ndv = number of decision variables : int
        bounds_min,bounds_max = numpy array that contains lower and upper bound of decision variables"""
        encoding_matrix = np.zeros((ndv, p, m), dtype='int32')
        n = 0
        nn = m
        for e in range(ndv):
            encoding_matrix[e, :, :] = population[:, n:nn]
            n = nn
            nn += m
        binary_list = np.array([2 ** (m - b - 1) for b in range(m)])
        decoding_variables = np.zeros((ndv, p, 1))
        for d in range(ndv):
            decoding_variables[d] = bmin[d] + \
                                    np.sum(encoding_matrix[d, :, :] * binary_list, axis=1).reshape((p, 1)) \
                                    * (bmax[d] - bmin[d]) / ((2 ** m) - 1)
        final = np.hstack((decoding_variables[0], decoding_variables[1]))
        if ndv > 2:
            for n in range(2, ndv):
                final = np.hstack((final, decoding_variables[n]))
        return final

    def elitizm(pop, objective_matrix, minimization=True):
        if not minimization:
            return [pop[np.argmax(objective_matrix)], np.argmax(objective_matrix)]
        else:
            return [pop[np.argmin(objective_matrix)], np.argmin(objective_matrix)]

    def selection(objective_matrix, population, selection_method='tournament', minimization=True):
        pop = np.zeros((p, m * ndv))
        if minimization is True:
            objective_matrix = -objective_matrix
        if selection_method is 'tournament':
            for s in range(p):
                n = 2
                indivs = np.random.randint(0, p, (n, 1))
                fitvalues = [objective_matrix[item] for item in indivs]
                position = indivs[fitvalues.index(max(fitvalues))]
                pop[s] = population[position]
            return pop

        else:
            raise TypeError("only 'tournament' selections can operate")

    def crossover(pop, cross_type='single point'):
        new_pop = np.copy(pop)
        random = np.random.rand(int(p / 2))
        cnum = sum(random <= pc)
        if cross_type == 'single point':
            c = 1
            while c <= cnum:
                r1 = np.random.randint(0, p)
                r2 = np.random.randint(0, p)
                if r1 != r2:
                    cross_point = np.random.randint(1, m * ndv)
                    new_pop[r1] = np.hstack((pop[r1, 0:cross_point], pop[r2, cross_point:]))
                    new_pop[r2] = np.hstack((pop[r2, 0:cross_point], pop[r1, cross_point:]))
                    c += 1
        else:
            raise TypeError('Crossover function only execute ''uniform'' and ''single point'' crossover')
        return new_pop

    def mutation(pop):
        mutation_random = np.random.rand(p * (m * ndv)).reshape((p, (m * ndv)))

        for a in range(p):
            for u in range((m * ndv)):
                if mutation_random[a, u] <= pm:
                    if pop[a, u] != 1:
                        pop[a, u] = 1
                    else:
                        pop[a, u] = 0
        return pop

    list1 = []

    for z in range(generation):
        decode1 = decoding(first_pop)
        fitness = fit_func(decode1)
        elit1_value = fitness[(elitizm(first_pop, fitness, minimization=minprob)[1])]
        reproduce_pop = selection(fitness, first_pop, minimization=minprob, selection_method='tournament')
        reproduce_pop2 = crossover(reproduce_pop, 'single point')
        reproduce_pop3 = mutation(reproduce_pop2)
        decode2 = decoding(reproduce_pop3)
        fitness2 = fit_func(decode2)
        elit2_value = fitness2[(elitizm(reproduce_pop3, fitness2, minimization=minprob)[1])]
        if minprob is False:
            if elit1_value >= elit2_value:
                reproduce_pop3[0] = elitizm(first_pop, fitness, minimization=minprob)[0]
        else:
            if elit1_value <= elit2_value:
                reproduce_pop3[0] = elitizm(first_pop, fitness, minimization=minprob)[0]
        if z % 50 == 0:
            print('generation = {0} and best value = {1}'.format(z + 50, elit1_value))
        first_pop = reproduce_pop3
        list1.append(elit1_value)

    return list1
