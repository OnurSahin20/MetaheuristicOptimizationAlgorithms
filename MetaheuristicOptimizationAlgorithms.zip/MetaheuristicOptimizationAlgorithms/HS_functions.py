
def harmony_search(hms,  par, hmcr ,nd, bmin, bmax, fit_func,stdtol=0, maxiter=100000, segment=300, minprob=True):
    import numpy as np
    hm = bmin + np.random.rand(hms, nd) * (bmax - bmin)
    obj_values = fit_func(hm)
    x = np.zeros((1, nd))
    list1 = []
    segment = np.array([segment] * nd)
    for z in range(maxiter):
        for d in range(nd):
            if np.random.rand() >= hmcr:
                x[0, d] = bmin[d] + np.random.rand() * (bmax[d] - bmin[d])
            else:
                d1 = int(hms * np.random.rand())

                x[0, d] = hm[d1, d]
                if np.random.rand() <= par:
                    bw = (bmax[d] - bmin[d]) / segment[d]
                    if np.random.rand() > 0.5:
                        x[0, d] = x[0, d] + bw * np.random.rand()
                    else:
                        x[0, d] = x[0, d] - bw * np.random.rand()
            if x[0, d] < bmin[d]:
                x[0, d] = bmin[d]
            elif x[0, d] > bmax[d]:
                x[0, d] = bmax[d]


        sol = fit_func(x)
        sol = sol[0, 0]
        hmax = np.amax(obj_values)
        hmax_loc = np.argmax(obj_values)
        hmin = np.amin(obj_values)
        hmin_loc = np.argmin(obj_values)


        if minprob is True:
            if sol <= hmax:
                hm[hmax_loc] = x
                obj_values[hmax_loc] = sol
            list1.append(np.amin(obj_values))
            if z % 200 == 0:
                print('generation = {0} and best value = {1}'.format(z + 50, np.amin(obj_values)))
        elif minprob is False:
            if sol >= hmin:
                hm[hmin_loc] = x
                obj_values[hmin_loc] = sol
            list1.append(np.amax(obj_values))
            if z % 200 == 0:
                print('generation = {0} and best value = {1}'.format(z + 50, np.amax(obj_values)))
        std = np.std(obj_values)
        if std<= stdtol:
            break
    return list1,z
