import numpy as np
from DEA_functions import dea
import matplotlib.pyplot as plt
import time
start = time.perf_counter()
CR = 0.5
nd = 10
P = 100
F = 0.8
Max_iter = 10000
lb = np.array([0] * nd)
ub = np.array([np.pi] * nd)


def michalewicz(xx):
    mm = 10
    n1 = np.shape(xx)[0]
    n2 = np.shape(xx)[1]
    values = np.zeros((n1, 1))
    for i in range(n1):
        s = 0
        for j in range(1, n2 + 1):
            s = s + np.sin(xx[i, j - 1]) * (np.sin(j * xx[i, j - 1] ** 2 / np.pi)) ** (2 * mm)
        values[i, 0] = -s
    return values


outputs = dea(P, F, CR, nd, lb, ub, michalewicz, Max_iter)

list1 = outputs[0]
list2 = range(0, outputs[1] + 1)
end = time.perf_counter()
print('Process time is {}'.format(end-start))
plt.plot(list2, list1, label="graph", color="red")
plt.semilogx()
plt.xlabel("GENERATİON", color="blue")
plt.ylabel("OBJECTİVE VALUES", color="blue")

plt.legend()
plt.show()
